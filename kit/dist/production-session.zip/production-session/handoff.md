# 핸드오프 — 컷 세션 → 총괄

Write at most 40 lines, one cut only. The reader is the next session's Claude. Leave out history; write only results and next steps.

```text
받는 세션: 총괄
보낸 세션: [컷 번호 3-1] · [날짜] · [이름]
컷 상태: [진행 / 검토 / 승인 / 보류]

[1] 확정된 것: [종류 · job · OK 대장 카드 기록함/못함 · 한계]
[2] 이번 세션 생성: 이미지 [N] / 영상 [N] / 약 [N] 크레딧 · 거절: [job — 이유]
[3] 바뀐 결정: [결정 — 근거]
[4] 새 실패 → 막는 문장: [ ]
[5] 총괄에 올릴 것: [이 컷 범위 밖]
[6] 다음 할 일: [ ]
```
